package ejercitacionIntegradora;

import java.util.Scanner;

public class Ejercicio8 {
    public static void main(String[] args) {
        /*
            Escribir un código que categorice la calificación 
            ingresada por un docente de la siguiente forma: 
            
            9-10: Ha obtenido una calificación sobresaliente 
            7-8: Ha obtenido una calificación notable 
            4-6: Ha obtenido un aprobado 
            1-3: Ha desaprobado
        
            Validar que la nota ingresada se encuentre entre 1 y 10. 
 
        */
        Scanner lector = new Scanner(System.in);
        
        System.out.println("Ingrese la nota: ");
        int nota = lector.nextInt();
        
        if (nota >= 1 && nota <= 10) 
        {
            switch (nota) {
                case 10:
                case 9:
                    System.out.println("sobresaliente");
                    break;
                case 8:
                case 7:
                    System.out.println("notable");
                    break;
                case 6:
                case 5:
                case 4:
                    System.out.println("aprobado");
                    break;
                case 3:
                case 2:
                case 1:
                    System.out.println("desaprobado");
                    break;
            }
        } 
        else 
        {
            System.out.println("Porfa, ingrese entre 1 y 10");
        }
    }
}
