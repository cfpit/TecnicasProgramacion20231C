package ejercitacionIntegradora;

import java.util.Scanner;

public class Ejercicio3 {
    public static void main(String[] args) {
        /*
            3) Crear un Algoritmo que lea tres números distintos 
            y nos diga cuál de ellos es el mayor (recuerda usar 
            la estructura condicional Si y los operadores lógicos).
        */
        
        Scanner lector = new Scanner(System.in);
        
        //ingreso de datos
        System.out.println("n1 = ");
        int n1 = lector.nextInt();
        
        System.out.println("n2 = ");
        int n2 = lector.nextInt();
        
        System.out.println("n3 = ");
        int n3 = lector.nextInt();
        
        //logica
        if (n1 != n2 && n1 != n3 && n2 != n3) 
        {
            if (n1 > n2 && n1 > n3) 
            {
                System.out.println("n1 = " + n1  + " es el mayor");
            }
            
            if (n2 > n1 && n2 > n3) 
            {
                System.out.println("n2 = " + n2  + " es el mayor");
            }
            
            if (n3 > n1 && n3 > n2) 
            {
                System.out.println("n3 = " + n3  + " es el mayor");
            }
        }
        else
        {
            System.out.println("No cumplen las condiciones");
        }
        
    }
}
