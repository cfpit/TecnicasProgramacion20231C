package ejemplo;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        //creo un objeto de la clase Scanner q leera dsd teclado
        Scanner lector = new Scanner(System.in);
        
        //ingreso de datos
        System.out.println("Decime que dia es: ");
        String dia = lector.next();
        
        System.out.println("Tenes dinero?: ");
        String dinero = lector.next();
        
        //logica
        if (dia.equals("sabado") && dinero.equals("si")) 
        {
            System.out.println("Salgo de paseo :)");
        } 
        else 
        {
            System.out.println("Me quedo :(");
        }
        
        
    }
}
