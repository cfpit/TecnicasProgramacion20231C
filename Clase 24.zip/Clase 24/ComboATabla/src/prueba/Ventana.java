/*En la clase principal Ventana, se definen dos variables estáticas: tableModel 
y totalesLabel. Estas variables serán utilizadas para acceder al modelo de tabla 
y al JLabel que muestra los totales.

El método main crea y muestra la interfaz gráfica en el hilo de eventos de Swing.

El método createAndShowGUI se encarga de construir la interfaz gráfica.

Se crea un objeto JFrame que representa la ventana principal de la aplicación.

Se crean los componentes de la interfaz, como etiquetas (JLabel), combos (JComboBox), 
campo de texto (JTextField), botones (JButton) y una tabla (JTable).

Se crea un modelo de tabla (DefaultTableModel) y se le agregan las columnas 
necesarias. El modelo se asigna a la tabla.

Se crea un objeto TableRowSorter para permitir el ordenamiento de filas en la tabla.

Se crea un objeto ActionListener para el botón "Agregar". Este ActionListener se 
encarga de obtener los valores seleccionados del combo de mes, del combo de tipo 
de impuesto y del campo de texto de importe. Luego, agrega una nueva fila con 
estos datos al modelo de tabla y limpia los campos de entrada.

Se crea otro objeto ActionListener para el botón "Totales". Este ActionListener 
calcula los totales de importe por mes llamando al método calculateMonthTotals. 
Luego, actualiza el texto del totalesLabel con los totales calculados.

Se crean paneles (JPanel) para organizar los componentes de la interfaz.

Se agregan los componentes a los paneles correspondientes y se configura la 
disposición de los paneles.

Finalmente, se agregan los paneles al containerPanel y se añade este último al 
contenido del JFrame. También se agrega el totalesLabel en la parte inferior.

Se empaqueta y se muestra el JFrame.

El método calculateMonthTotals recibe el modelo de tabla y calcula los totales 
de importe por mes. Recorre todas las filas de la tabla, obteniendo el mes y 
el importe de cada fila. Luego, suma los importes correspondientes al mes en un 
Map que almacena los totales. Al final, devuelve el Map con los totales calculados.

*/

package prueba;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;


public class Ventana {
    //atributos
    private static DefaultTableModel tableModel;
    private static JLabel totalesLabel;

    //constructor
    public Ventana() {}

    //metodo main
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> createAndShowGUI());
    }
    
    
    private static void createAndShowGUI() {
        JFrame frame = new JFrame("JTable Example");
        
        //cuando se cierra la ventana principal, la aplicación se termina y se 
        //detiene su ejecución.
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        // Crear los componentes de la interfaz
        JLabel mesLabel = new JLabel("Mes:");
        JComboBox<String> mesComboBox = new JComboBox<>(new String[]{"Enero", "Febrero", "Marzo"});
        JLabel tipoImpuestoLabel = new JLabel("Tipo de Impuesto:");
        JComboBox<String> tipoImpuestoComboBox = new JComboBox<>(new String[]{"Impuesto 1", "Impuesto 2", "Impuesto 3"});
        JLabel importeLabel = new JLabel("Importe:");
        JTextField importeTextField = new JTextField(10);//10 es el ancho en cantidad de columnas del jTextField
        JButton addButton = new JButton("Agregar");
        JButton totalesButton = new JButton("Totales");
        JTable table = new JTable();

        // Crear el modelo de tabla
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Mes");
        tableModel.addColumn("Tipo de Impuesto");
        tableModel.addColumn("Importe");
        table.setModel(tableModel);

        // Agregar ordenamiento por columna al JTable
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);

        // Crear el ActionListener para el botón Agregar
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //capturar el contenido de los combos y la caja de texto y guardarlos en variables
                String mes = mesComboBox.getSelectedItem().toString();
                String tipoImpuesto = tipoImpuestoComboBox.getSelectedItem().toString();
                String importe = importeTextField.getText();

                // Agregar los datos a la tabla
                tableModel.addRow(new Object[]{mes, tipoImpuesto, importe});

                // Limpiar los campos de entrada
                mesComboBox.setSelectedIndex(0);
                tipoImpuestoComboBox.setSelectedIndex(0);
                importeTextField.setText("");
            }
        });

        // Crear el ActionListener para el botón Totales
        totalesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Calcular el total de cada mes
                Map<String, Double> totals = calculateMonthTotals(tableModel);

                // Actualizar el texto del JLabel con los totales
                StringBuilder sb = new StringBuilder();
                for (Map.Entry<String, Double> entry : totals.entrySet()) {
                    sb.append(entry.getKey()).append(": ").append(entry.getValue()).append(" $      \n");
                }
                totalesLabel.setText(sb.toString());
            }
        });

        // Crear el panel principal y agregar los componentes
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new FlowLayout());
        mainPanel.add(mesLabel);
        mainPanel.add(mesComboBox);
        mainPanel.add(tipoImpuestoLabel);
        mainPanel.add(tipoImpuestoComboBox);
        mainPanel.add(importeLabel);
        mainPanel.add(importeTextField);
        mainPanel.add(addButton);
        mainPanel.add(totalesButton);

        // Crear el panel del JTable
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(new BorderLayout());
        tablePanel.add(new JScrollPane(table), BorderLayout.CENTER);

        // Crear el panel contenedor y agregar los paneles principales
        JPanel containerPanel = new JPanel();
        containerPanel.setLayout(new BorderLayout());
        containerPanel.add(mainPanel, BorderLayout.NORTH);
        containerPanel.add(tablePanel, BorderLayout.CENTER);

        // Agregar el panel contenedor al marco
        frame.getContentPane().add(containerPanel);

        // Crear el JLabel para mostrar los totales
        totalesLabel = new JLabel();
        frame.getContentPane().add(totalesLabel, BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);
    }

    private static Map<String, Double> calculateMonthTotals(DefaultTableModel tableModel) {
        Map<String, Double> totals = new HashMap<>();

        int rowCount = tableModel.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            String mes = tableModel.getValueAt(i, 0).toString();
            double importe = Double.parseDouble(tableModel.getValueAt(i, 2).toString());

            if (totals.containsKey(mes)) {
                double total = totals.get(mes);
                total += importe;
                totals.put(mes, total);
            } else {
                totals.put(mes, importe);
            }
        }

        return totals;
    }
}





