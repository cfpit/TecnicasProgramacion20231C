package EjercitacionEstructuraCondicional;

import java.util.Scanner;

public class Ejercicio7 {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        
        //ingreso de datos
        System.out.println("ingrese el tipo de uva(a-b): ");
        String ti = lector.next();
        
        System.out.println("ingrese el tamaño de la uva(1-2): ");
        int ta = lector.nextInt();
        
        System.out.println("ingrese el precio por kilo: ");
        double p = lector.nextDouble();
        
        System.out.println("ingrese la cantidad de kilos: ");
        int k = lector.nextInt();
        
        //logica
        if (ti.equals("a")) 
        {
            if (ta == 1) 
            {
                System.out.println("Total: "+k * (p + 0.2)+" $");
            } 
            else 
            {
                System.out.println("Total: "+k * (p + 0.3)+" $");
            }
        } 
        else 
        {
            if (ta == 1) 
            {
                System.out.println("Total: "+k * (p - 0.3)+" $");
            } 
            else 
            {
                System.out.println("Total: "+k * (p - 0.5)+" $");
            }
        }
    }
}



