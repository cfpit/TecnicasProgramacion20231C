package ejercitacionIntegradora;

import java.util.Scanner;

public class Ejercicio6 {
    public static void main(String[] args) {
        
        /*
            Realizar un algoritmo (y su correspondiente diagrama de 
            flujo) que dado un número entero, visualice en pantalla 
            si es par o impar (para que un número sea par, se debe 
            dividir por dos y su resto debe ser 0). 
        */
        Scanner lector = new Scanner(System.in);
        
        System.out.println("Ingrese un numero entero: ");
        int n = lector.nextInt();
        
        if (n % 2 == 0) 
        {
            System.out.println("n es par");
        } 
        else 
        {
            System.out.println("n es impar");
        }
        
        
    }
}
