package arrays;

import java.util.Arrays;

public class Test {
    public static void main(String[] args) {
        //declaro un array de enteros
//        int [] edades;
        
        //instancio en la RAM el array
//        edades = new int [5];//20 bytes
        
        //inicializo el array
//        edades[0]= 1;
//        edades[1]= 3;
//        edades[2]= 8;
//        edades[3]= 23;
//        edades[4]= 99;

        int [] edades = {1,3,8,23,99};
        
        System.out.println("valor del indice 3: " + edades[3]);
        
        System.out.print("Contenido del array: ");
        System.out.println(Arrays.toString(edades));
        System.out.print("Logitud del array: ");
        System.out.println(edades.length);
        
        System.out.println("Mayores de edad: ");
        for (int i = 0; i < edades.length; i++) {
            if (edades[i] >= 18) 
            {
                System.out.println(edades[i]);
            }
        }
        
        
    }
}
