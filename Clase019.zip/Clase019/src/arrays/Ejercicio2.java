package arrays;

public class Ejercicio2 {
    public static void main(String[] args) {
        
        double [] infla = {0.8, 0.1, 0.3, 0.4, 0.3, 0.6, 0.5, 0.3, 0.7, 0.3, 0.2, 0.9};
        
        double max = 0;
        double min = infla[0];
        int mesMax = 0, mesMin = 0;
        double total = 0;
        
        for (int i = 0; i < infla.length; i++) 
        {
            //totalizo el array
            total = total + infla[i];
            
            //obtengo el maximo
            if (infla[i] > max) {
                max = infla[i];
                mesMax = i + 1;
            }
            
            //obtengo el minimo
            if (infla[i] < min) {
                min = infla[i];
                mesMin = i + 1;
            }
        }
        
        System.out.println("Promedio: " + total / 12);//0.45
        System.out.println("Maximo: " + max + " Mes: " + mesMax);//0.9 en mes 12
        System.out.println("Minimo: " + min + " Mes: " + mesMin);//0.1 en mes 2
        
        
    }
}
