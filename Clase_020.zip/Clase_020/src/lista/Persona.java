package lista;

public class Persona {
    //atributos
    private String nombre;
    private String apellido;
    
    //constructores
    //vacio
    public Persona() {}

    //parametrizado
    public Persona(String nombre, String apellido) {
        this.nombre = nombre;
        this.apellido = apellido;
    }
    
    //getters y setters
    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    //metodos
    public String toString() {
        return nombre + " " + apellido;
    }
}
