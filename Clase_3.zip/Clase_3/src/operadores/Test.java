
package operadores;


public class Test {
    public static void main(String[] args) {
        System.out.println("Operadores aritmeticos: ");
        
        int n1 = 10; 
        int n2 = 5;
        
        System.out.println("n1 mas n2 es " + (n1 + n2));
        System.out.println("n1 menos n2 es " + (n1 - n2));
        System.out.println("n1 por n2 es " + n1 * n2);
        System.out.println("n1 dividido por n2 es " + n1 / n2);
        
        System.out.println("n1 resto n2 es " + n1 % n2);
        
        System.out.println("Operadores relacionales: ");
        
        System.out.println("n1 > n2 = " + (n1 > n2));//true
        System.out.println("n1 < n2 = " + (n1 < n2));//false
        System.out.println("n1 = n2 = " + (n1 == n2));//false
        System.out.println("n1 != n2 = " + (n1 != n2));//true
        System.out.println("n1 >= n2 = " + (n1 >= n2));//true
        System.out.println("n1 <= n2 = " + (n1 <= n2));//false
        System.out.println(5 > 3);//true

        
        System.out.println("Operadores incrementales: ");
        
        int n = 1;
        System.out.println("n = " + n);//n = 1
        
        n = n + 1;
        System.out.println("n = " + n);//n = 2
        
        n += 5;
        System.out.println("n = " + n);//n = 7
        
        n ++;
        System.out.println("n = " + n);//n = 8
        
        n --;
        System.out.println("n = " + n);//n = 7
        
        n *= 4;// n = n * 4
        System.out.println("n = " + n);//n = 28

        n %= 2;// n = n % 2
        System.out.println("n = " + n);//n = 0
        
        System.out.println("Operadores logicos: ");
        
        
        
        
        
        
        
        
        
    }
}
