/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inicio;

/**
 *
 * @author Aula 7 - Docente
 */
public class Test {
    public static void main(String[] args) {
        System.out.println("Hola Mundo!!");
        System.out.println("Hola Argentina!!");
        
        //datos
        //constante
        final double PI = 3.14;//constante
        final int IVA = 21;
        
        int edad = 49;//variable
        
        /*
        esto es
        un comentario
        de bloque
        */
        
        String frase = "Detesto la vecina!!!";
        
        char simbolo = '@';
        
        boolean abierto = true;//false
        
        //muestro la edad
        System.out.println("La edad es de " + edad + " años");
        
        
        
        
        
        
        
        
        
        
    }
}
