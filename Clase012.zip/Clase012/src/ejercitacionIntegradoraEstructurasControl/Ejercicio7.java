package ejercitacionIntegradoraEstructurasControl;

import java.util.Scanner;

public class Ejercicio7 {
    public static void main(String[] args) {
        /*
            7) Crear un Algoritmo que dado un año, nos diga si es bisiesto o no. 
            Un año es bisiesto bajo las siguientes condiciones: Un año divisible 
            por 4 es bisiesto y no debe ser divisible entre 100. Si un año es 
            divisible entre 100 y además es divisible entre 400, también resulta 
            bisiesto.
        */
        Scanner lector = new Scanner(System.in);
        
        //ingreso de datos
        System.out.println("ingrese un año, porfa: ");
        int año = lector.nextInt();
        
        if (año % 4 == 0 && año % 100 != 0  || año % 100 == 0 && año % 400 == 0) 
        {
            System.out.println("El año " + año + " es bisiesto");
        } 
        else 
        {
            System.out.println("El año " + año + " NO es bisiesto");
        }
    }
}
